# NXD

Personal site for [@nxd_.10](https://www.instagram.com/nxd_.10/): home, journal, photo gallery, about page and a contact page. It is one static `index.html` plus a folder of photos, so it needs no build step.

## Put it online with GitHub Pages

1. Create a new repository on GitHub (for example `nxd-site`). Set it to Public.
2. Click **Add file > Upload files** and drag in everything from this folder: `index.html`, `.nojekyll`, `README.md` and the `img` folder. Click **Commit changes**.
3. Open **Settings > Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch**, choose branch `main` and folder `/ (root)`, then save.
4. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/nxd-site/`.

If the `.nojekyll` file does not show up in the upload dialog (hidden files sometimes get skipped), the site still works.

## Edit the site

Everything you will want to change is at the top of the `<script>` section in `index.html`.

- **`SITE`**: the Instagram handle and link, the tagline and the intro line.
- **`POSTS`**: the journal. Each post has a title, category, date, excerpt and body. The five posts are samples, so replace them with real writing and delete the `sample: true` flag to remove the "Sample post" label.
- **`POST_PHOTO`**: which photo each post uses.
- **`FRAMES`**: the gallery. Each entry is a photo number, a title and a crop focus.

## Photos

`img/01.jpg` to `img/20.jpg` are the full-size versions shown in the viewer. `img/t01.jpg` to `img/t20.jpg` are the small versions used in the grids. To swap a photo, replace both files with the same number. To add one, add `21.jpg` and `t21.jpg` and a new line in `FRAMES`.

A photo around 1600 px on its long side, saved as JPG, works well. The thumbnail can be about 700 px.

## Contact form

The form has no inbox behind it, because GitHub Pages only serves static files. It prepares a message that the visitor copies and sends as an Instagram DM. To receive messages by email instead, create a form on a service such as Formspree or Web3Forms and point the form's submit handler (`bindContact` in `index.html`) at the address they give you.

## Fonts

Syne, Instrument Sans and DM Mono load from Google Fonts. The page falls back to system fonts if they are blocked.
